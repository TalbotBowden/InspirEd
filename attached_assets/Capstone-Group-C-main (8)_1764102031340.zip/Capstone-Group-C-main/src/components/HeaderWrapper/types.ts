type HeaderWrapperProps = {
  style?: object;
  contentContainerStyle?: object;
  children: React.ReactNode;
};

export type { HeaderWrapperProps };
