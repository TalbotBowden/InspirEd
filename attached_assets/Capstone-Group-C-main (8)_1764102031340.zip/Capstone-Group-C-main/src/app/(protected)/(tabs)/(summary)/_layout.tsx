import { Stack } from "expo-router";

export default function SummaryLayout() {
  return (
    <Stack
      screenOptions={{
        title: "Summary",
      }}
    />
  );
}
