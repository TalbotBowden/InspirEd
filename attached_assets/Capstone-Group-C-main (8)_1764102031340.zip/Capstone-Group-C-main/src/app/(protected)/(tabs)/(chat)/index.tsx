import Chat from "@/screens/Chat";

export default function ChatScreen() {
  return <Chat />;
}
