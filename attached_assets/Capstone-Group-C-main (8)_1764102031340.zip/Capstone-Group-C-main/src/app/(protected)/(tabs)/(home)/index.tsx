import Home from "@/screens/Home";

export default function HomeScreen() {
  return <Home />;
}
