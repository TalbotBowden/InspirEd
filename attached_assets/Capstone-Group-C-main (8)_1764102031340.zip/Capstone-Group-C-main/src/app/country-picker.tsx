import CountryPicker from "@/screens/CountryPicker";

export default function CountryPickerScreen() {
  return <CountryPicker />;
}
