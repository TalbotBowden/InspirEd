import Login from "@/screens/Login";

export default function LoginScreen() {
  return <Login />;
}
